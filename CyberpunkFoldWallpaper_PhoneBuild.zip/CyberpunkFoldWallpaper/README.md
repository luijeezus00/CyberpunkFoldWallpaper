# Cyberpunk Fold live wallpaper (source project)

This is an Android Studio Java project, **not a prebuilt APK**.

## Build and install
1. Open this folder in Android Studio (with Android SDK 35 installed).
2. Allow Gradle sync to finish; select **Build > Build APK(s)**.
3. Transfer `app/build/outputs/apk/debug/app-debug.apk` to the Pixel and install it (Android may ask to allow installation from this source).
4. Open **Cyberpunk Fold** from the app drawer and choose **Set wallpaper**.

## Behavior
Uses the included square neon Tokyo art. A fold/unfold display-ratio change triggers a ~900ms eased crop/zoom transition and subtle temporary shimmer. At rest the wallpaper does not continuously animate. Exact fold behavior depends on Pixel firmware, display reporting, and launcher wallpaper cropping; test on-device. This is an original approximation, not Google's proprietary Tidal Swirls engine. No special permissions or internet access are required.

## Adjustments
In `CityWallpaperService.java`, `.72f` is the open/closed aspect-ratio threshold, `durationMs` is transition duration, and the `.66f-.16f*open` expression controls the horizontal focal point.
