package com.example.cyberpunkfold;
import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Intent;
import android.os.Bundle;
public class LaunchActivity extends Activity {
 @Override public void onCreate(Bundle state) { super.onCreate(state);
  Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
  i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, new android.content.ComponentName(this, CityWallpaperService.class));
  try { startActivity(i); } catch (Exception e) { startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)); }
  finish();
 }
}
