package com.example.cyberpunkfold;

import android.service.wallpaper.WallpaperService;
import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.SurfaceHolder;
import android.hardware.display.DisplayManager;
import android.view.Display;

public class CityWallpaperService extends WallpaperService {
 @Override public Engine onCreateEngine() { return new CityEngine(); }
 class CityEngine extends Engine implements DisplayManager.DisplayListener {
  final Handler handler = new Handler(Looper.getMainLooper());
  final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
  Bitmap image;
  DisplayManager displays;
  boolean visible = false;
  int width = 1, height = 1;
  float currentOpen = 0f, fromOpen = 0f, targetOpen = 0f;
  long animationStart = 0;
  final long durationMs = 900;
  final Runnable frame = this::render;

  @Override public void onCreate(SurfaceHolder holder) {
   super.onCreate(holder);
   image = BitmapFactory.decodeResource(getResources(), R.drawable.city);
   displays = (DisplayManager)getSystemService(DISPLAY_SERVICE);
   displays.registerDisplayListener(this, handler);
  }
  @Override public void onDestroy() {
   visible = false; handler.removeCallbacks(frame);
   if (displays != null) displays.unregisterDisplayListener(this);
   if (image != null) image.recycle();
   super.onDestroy();
  }
  @Override public void onVisibilityChanged(boolean v) { visible=v; if(v) { detectState(); render(); } else handler.removeCallbacks(frame); }
  @Override public void onSurfaceChanged(SurfaceHolder holder,int format,int w,int h) { super.onSurfaceChanged(holder,format,w,h); width=w; height=h; detectState(); render(); }
  @Override public void onDesiredSizeChanged(int w,int h) { super.onDesiredSizeChanged(w,h); detectState(); render(); }
  @Override public void onDisplayAdded(int id) { detectState(); }
  @Override public void onDisplayRemoved(int id) { detectState(); }
  @Override public void onDisplayChanged(int id) { detectState(); }

  void detectState() {
   // Foldable wallpaper display switches can arrive before the surface resize.
   // Use the active display aspect ratio, with the surface as a fallback.
   float ratio = width/(float)Math.max(1,height);
   Display display = displays == null ? null : displays.getDisplay(Display.DEFAULT_DISPLAY);
   if (display != null) {
    android.graphics.Point p = new android.graphics.Point(); display.getRealSize(p);
    if (p.y > 0) ratio = p.x/(float)p.y;
   }
   float next = ratio > .72f ? 1f : 0f;
   if (next != targetOpen) {
    updateProgress(); fromOpen=currentOpen; targetOpen=next;
    animationStart=SystemClock.uptimeMillis();
    if (visible) render();
   }
  }
  void updateProgress() {
   if (animationStart==0) { currentOpen=targetOpen; return; }
   float t=Math.min(1f,(SystemClock.uptimeMillis()-animationStart)/(float)durationMs);
   float smooth=t*t*(3-2*t);
   currentOpen=fromOpen+(targetOpen-fromOpen)*smooth;
  }
  void render() {
   handler.removeCallbacks(frame);
   if(!visible || image==null || !getSurfaceHolder().getSurface().isValid()) return;
   updateProgress();
   Canvas canvas=null;
   try {
    canvas=getSurfaceHolder().lockCanvas();
    if(canvas==null) return;
    int w=canvas.getWidth(), h=canvas.getHeight();
    canvas.drawColor(Color.BLACK);
    // Cover the surface without letterboxing. Closed view favors the car/right side.
    // Unfolding gradually widens the view and exposes more of the left skyline.
    float open=currentOpen;
    float zoom=1.12f - .10f*open;
    float scale=Math.max(w/(float)image.getWidth(),h/(float)image.getHeight())*zoom;
    float iw=image.getWidth()*scale, ih=image.getHeight()*scale;
    float maxShift=Math.max(0,iw-w);
    float left=-maxShift*(.66f-.16f*open);
    float top=-(ih-h)*.5f;
    paint.setAlpha(255);
    canvas.drawBitmap(image,null,new RectF(left,top,left+iw,top+ih),paint);
    // Brief neon shimmer during transition, completely still at rest.
    float motion=Math.abs(targetOpen-currentOpen);
    if(motion>.002f) {
     paint.setColor(Color.argb((int)(18*motion),35,205,255));
     canvas.drawRect(0,h*.68f,w,h,paint);
     paint.setColor(Color.WHITE);
    }
   } catch(Exception ignored) { } finally { if(canvas!=null) try { getSurfaceHolder().unlockCanvasAndPost(canvas); } catch(Exception ignored) {} }
   if(Math.abs(targetOpen-currentOpen)>.002f) handler.postDelayed(frame,33);
  }
 }
}
